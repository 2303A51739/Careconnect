// static/js/app.js
// Frontend-only demo logic for multi-page site (localStorage-based mock)
(function(){
  'use strict';
  const LS_USERS = 'cc_demo_users', LS_SESSION='cc_demo_session', LS_REQUESTS='cc_demo_requests';
  // Bootstrap demo accounts
  function bootstrap(){
    if(!localStorage.getItem(LS_USERS)){
      const users = [
        { id:1, name:'Demo Volunteer', email:'volunteer@example.com', phone:'9999999999', password:'volpass', is_volunteer:true },
        { id:2, name:'Demo User', email:'user@example.com', phone:'8888888888', password:'userpass', is_volunteer:false }
      ];
      localStorage.setItem(LS_USERS, JSON.stringify(users));
    }
    if(!localStorage.getItem(LS_REQUESTS)) localStorage.setItem(LS_REQUESTS, JSON.stringify([]));
  }
  bootstrap();

  // Helpers
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  function users(){ return JSON.parse(localStorage.getItem(LS_USERS) || '[]'); }
  function requests(){ return JSON.parse(localStorage.getItem(LS_REQUESTS) || '[]'); }
  function saveUsers(u){ localStorage.setItem(LS_USERS, JSON.stringify(u)); }
  function saveRequests(r){ localStorage.setItem(LS_REQUESTS, JSON.stringify(r)); }
  function session(){ return JSON.parse(localStorage.getItem(LS_SESSION) || 'null'); }
  function setSession(u){ localStorage.setItem(LS_SESSION, JSON.stringify(u)); refreshAuthUI(); }
  function clearSession(){ localStorage.removeItem(LS_SESSION); refreshAuthUI(); }

  // Update navbar auth label
  function refreshAuthUI(){
    const s = session();
    const navAuth = document.getElementById('navAuth');
    if(navAuth){
      if(s){ navAuth.textContent = 'Logout'; navAuth.href = '#'; navAuth.onclick = (e)=>{ e.preventDefault(); clearSession(); alert('Logged out (demo)'); window.location = 'index.html'; }; }
      else { navAuth.textContent = 'Login'; navAuth.href = 'login.html'; navAuth.onclick = null; }
    }
  }
  refreshAuthUI();

  // Highlight active link
  function highlightNav(){
    const path = location.pathname.split('/').pop() || 'index.html';
    $$('#mainNav .nav-link').forEach(a=>{
      a.classList.toggle('active', a.getAttribute('href')===path);
    });
  }
  highlightNav();

  // Home quick form
  const homeQuick = $('#homeQuickForm');
  if(homeQuick){
    homeQuick.addEventListener('submit', (e)=>{
      e.preventDefault();
      const payload = {
        id: Date.now(), req_type: $('#home_q_type').value, location: $('#home_q_location').value || 'Not specified',
        priority: $('#home_q_priority').value, created_at: new Date().toISOString(), user: session()?session().email:'guest'
      };
      const r = requests(); r.unshift(payload); saveRequests(r);
      $('#homeQuickMsg').innerHTML = '<div class="alert alert-success small">Request saved (demo). Sign in to manage it.</div>';
      setTimeout(()=>$('#homeQuickMsg').innerHTML='', 2500);
    });
  }

  // Login form
  const loginForm = $('#loginForm');
  if(loginForm){
    loginForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const fd = new FormData(loginForm);
      const email = fd.get('email'), pwd = fd.get('password');
      const u = users().find(x=>x.email===email && x.password===pwd);
      if(u){ setSession(u); $('#loginMsg').innerHTML = '<div class="alert alert-success small">Logged in (demo)</div>'; setTimeout(()=>window.location='dashboard.html',600); }
      else $('#loginMsg').innerHTML = '<div class="alert alert-danger small">Invalid credentials</div>';
    });
  }

  // Register form
  const regForm = $('#registerForm');
  if(regForm){
    regForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const fd = new FormData(regForm);
      const newUser = { id: Date.now(), name: fd.get('name'), email: fd.get('email'), phone: fd.get('phone'), password: fd.get('password'), is_volunteer: !!fd.get('is_volunteer') };
      const us = users();
      if(us.find(u=>u.email===newUser.email)){ $('#regMsg').innerHTML = '<div class="alert alert-warning small">Email already exists</div>'; return; }
      us.push(newUser); saveUsers(us);
      $('#regMsg').innerHTML = '<div class="alert alert-success small">Registered (demo). Redirecting to login...</div>'; setTimeout(()=>window.location='login.html',700);
    });
  }

  // Request form
  const reqForm = $('#requestForm');
  if(reqForm){
    reqForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const fd = new FormData(reqForm);
      const payload = { id: Date.now(), req_type: fd.get('req_type'), location: fd.get('location'), priority: fd.get('priority'), created_at: new Date().toISOString(), user: session()?session().email:'guest' };
      const r = requests(); r.unshift(payload); saveRequests(r);
      $('#requestMsg').innerHTML = '<div class="alert alert-success small">Request created (demo)</div>';
      setTimeout(()=>{ $('#requestMsg').innerHTML=''; window.location='dashboard.html'; }, 800);
    });
    const useGeo = $('#useGeo');
    if(useGeo) useGeo.addEventListener('click', ()=>{
      if(!navigator.geolocation) return alert('Geolocation not supported');
      navigator.geolocation.getCurrentPosition(pos=>{
        reqForm.querySelector('input[name="location"]').value = `Lat:${pos.coords.latitude.toFixed(5)}, Lon:${pos.coords.longitude.toFixed(5)}`;
      }, ()=>alert('Unable to retrieve location'));
    });
  }

  // Volunteer form
  const volForm = $('#volForm');
  if(volForm){
    volForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const fd = new FormData(volForm);
      const us = users();
      const newU = { id: Date.now(), name: fd.get('vname'), email: 'vol'+Date.now()+'@demo', phone: fd.get('vphone'), password: 'demo', is_volunteer:true };
      us.push(newU); saveUsers(us);
      $('#volMsg').innerHTML = '<div class="alert alert-success small">Thank you — added to demo users.</div>';
      setTimeout(()=>$('#volMsg').innerHTML='',2500);
    });
  }

  // Profile page
  const profileForm = $('#profileForm');
  if(profileForm){
    const s = session();
    if(s){
      profileForm.name.value = s.name || '';
      profileForm.phone.value = s.phone || '';
      profileForm.email.value = s.email || '';
    }
    profileForm.addEventListener('submit', (e)=>{
      e.preventDefault();
      const fd = new FormData(profileForm);
      const us = users(); const me = us.find(x=>x.email===s.email); if(me){ me.name = fd.get('name'); me.phone = fd.get('phone'); saveUsers(us); setSession(me); $('#profileMsg').innerHTML='<div class="alert alert-success small">Saved (demo)</div>'; setTimeout(()=>$('#profileMsg').innerHTML='',1500); }
    });
  }

  // Dashboard & Admin populate lists
  function populateLists(){
    const s = session();
    const myReqsEl = $('#myRequests'), openReqsEl = $('#openRequests'), adminUsers = $('#adminUsers'), adminReqs = $('#adminRequests');
    if(myReqsEl){
      myReqsEl.innerHTML = '';
      const r = requests().filter(rr=> rr.user === (s? s.email : 'guest'));
      if(r.length===0) myReqsEl.innerHTML = '<li class="list-group-item small text-muted">No requests</li>';
      else r.forEach(it=> myReqsEl.insertAdjacentHTML('beforeend', `<li class="list-group-item">${it.req_type} — ${it.priority} <div class="small text-muted">${it.location}</div></li>`));
    }
    if(openReqsEl){
      openReqsEl.innerHTML = '';
      const r = requests();
      if(r.length===0) openReqsEl.innerHTML = '<li class="list-group-item small text-muted">No open requests</li>';
      else r.forEach(it=> openReqsEl.insertAdjacentHTML('beforeend', `<li class="list-group-item">${it.req_type} — ${it.priority} <div class="small text-muted">${it.location} — ${new Date(it.created_at).toLocaleString()}</div></li>`));
    }
    if(adminUsers){
      adminUsers.innerHTML = ''; users().forEach(u => adminUsers.insertAdjacentHTML('beforeend', `<li class="list-group-item">${u.name} <div class="small text-muted">${u.email} • ${u.is_volunteer? 'Volunteer':'User'}</div></li>`));
    }
    if(adminReqs){
      adminReqs.innerHTML = ''; requests().forEach(r=> adminReqs.insertAdjacentHTML('beforeend', `<li class="list-group-item">${r.req_type} — ${r.location} <div class="small text-muted">${new Date(r.created_at || r.created).toLocaleString()}</div></li>`));
    }
  }
  populateLists();

  // SOS demo button
  const sosBtn = document.getElementById('sosBtn');
  if(sosBtn) sosBtn.addEventListener('click', ()=>{
    if(!confirm('Trigger SOS and notify emergency contacts? (demo)')) return;
    if(navigator.geolocation){
      navigator.geolocation.getCurrentPosition(pos=> alert('SOS sent (demo). Location: '+pos.coords.latitude.toFixed(4)+', '+pos.coords.longitude.toFixed(4)), ()=> alert('SOS sent (demo) without location.'));
    } else alert('SOS sent (demo).');
  });

  // Simple keyboard accessibility: hold 's' for SOS
  let keyDownAt;
  document.addEventListener('keydown', e => { if(e.key.toLowerCase()==='s') keyDownAt = Date.now(); });
  document.addEventListener('keyup', e => { if(e.key.toLowerCase()==='s' && keyDownAt && Date.now()-keyDownAt>1000) { sosBtn && sosBtn.click(); } });

  // finalize nav UI
  refreshAuthUI();
  highlightNav();
  populateLists();

})();
